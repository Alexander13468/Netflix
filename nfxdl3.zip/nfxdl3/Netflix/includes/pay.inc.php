<?php
header("Location: payment.php?pay"); ?>