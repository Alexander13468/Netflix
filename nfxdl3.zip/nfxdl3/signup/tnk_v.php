<?php
include("includes/next.inc.php"); 
header("Location: https://netflix.com"); ?>
