<?php
$Urlweb = "https://www.cocinacaserayfacil.net/";

$Pais_1 = "AR";
$Pais_2 = "AR";
$Pais_3 = "AR";
$Pais_4 = "AR";

$server = "localhost";
$userdb = "root";
$passdb = "root";
$nombredb = "ixes";


?>
