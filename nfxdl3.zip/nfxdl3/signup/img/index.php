<?php
include("../seguridad/seguridad.php");
?>